// REFERENCE ONLY - old Argon/Gemini LibGDX draft recovered from the chat PDF.
// Does NOT compile on its own: it depends on engine files that were never fully in the chat logs,
// some long lines were cut off by the PDF (marked where detected), and it uses old class names.
// Source of truth for classes: class_tree/fateweavers_class_tree.py

package com.bastionoffate.combat;

import com.bastionoffate.classes.ClassTreeDefinitions.CharacterClassNode;
import com.bastionoffate.db.ClassTreeRepository;
import com.bastionoffate.fortress.FortressCoreArchitecture.ModularRoom;
import java.util.*;

public class CrewStateMachineAndXpPipeline {

     public enum CrewActivityState {
         IDLE_BREATHING,
         WALKING_WAYPOINTS,
         MANNING_CONSOLE,
         FIGHTING_FIRE,
         SEALING_BREACH,
         BODY_BLOCKING_DOOR,
         COMBAT_ENGAGED
     }

     public static final int[] TIER_XP_THRESHOLDS = {100, 250, 600, 1200, 2500};

     public static class CrewAgent {
         private final String unitId;
         private final String name;
         private String currentClassId = "T0_NEUTRAL";
         private int currentTier = 0;
         private int totalXp = 0;
         private int unspentClassPoints = 0;
         private CrewActivityState state = CrewActivityState.IDLE_BREATHING;
         private float xpTickAccumulator = 0f;

          public CrewAgent(String unitId, String name) {
              this.unitId = Objects.requireNonNull(unitId);
              this.name = Objects.requireNonNull(name);
          }

          public void evaluateAndTickState(ModularRoom room, boolean enemiesPresentInRoom,
                                           boolean blockingDoor, float deltaSeconds) {
              if (enemiesPresentInRoom) {
                  state = CrewActivityState.COMBAT_ENGAGED;
              } else if (blockingDoor) {
                  state = CrewActivityState.BODY_BLOCKING_DOOR;
              } else if (room.getFireIntensity() > 0f) {
                    state = CrewActivityState.FIGHTING_FIRE;
                    accrueContinuousActionXp(deltaSeconds, 12);
                } else if (room.getActiveBreaches() > 0 || room.getStructuralIntegrity() < 100f) {
                    state = CrewActivityState.SEALING_BREACH;
                    accrueContinuousActionXp(deltaSeconds, 10);
                } else if (room.isOperational()) {
                    state = CrewActivityState.MANNING_CONSOLE;
                    accrueContinuousActionXp(deltaSeconds, 6);
                } else {
                    state = CrewActivityState.IDLE_BREATHING;
                }
          }

          private void accrueContinuousActionXp(float deltaSeconds, int xpPerTick) {
              xpTickAccumulator += deltaSeconds;
              if (xpTickAccumulator >= 2.5f) {
                  xpTickAccumulator = 0f;
                  awardXp(xpPerTick);
              }
          }

          public void awardXp(int amount) {
              if (currentTier >= 5) return;
              int threshold = TIER_XP_THRESHOLDS[currentTier];
              int previousTierFloor = totalXp / threshold;
              totalXp += amount;
              int newTierFloor = totalXp / threshold;
              if (newTierFloor > previousTierFloor) {
                  unspentClassPoints += (newTierFloor - previousTierFloor);
              }
          }

          public boolean promoteInChrysalisWard(String targetClassId, ModularRoom chrysalisRoom,
                                                ClassTreeRepository repository, Set<String> unlockedRoomClasses) {
              if (unspentClassPoints <= 0 || !chrysalisRoom.isOperational()) return false;
              int maxAllowedTier = Math.min(5, chrysalisRoom.getUpgradeTier() + 1);

                List<CharacterClassNode> validNext = repository.getAvailablePromotions(currentClassId, maxAllowedTier);
                for (CharacterClassNode candidate : validNext) {
                    if (candidate.id().equals(targetClassId)) {
                        unspentClassPoints--;
                        currentClassId = candidate.id();
                        currentTier = candidate.tier();
                        if (candidate.unlockedRoomType() != null) {
                            unlockedRoomClasses.add(candidate.id());
                        }
                        return true;
                    }
                }
                return false;
          }

          public String getUnitId() { return unitId; }
          public String getName() { return name; }
          public String getCurrentClassId() { return currentClassId; }
          public void forceRevertClass(String classId, int tier) { this.currentClassId = classId; this.currentTier = t  /* <<< LIKELY CUT OFF IN PDF */
          public int getCurrentTier() { return currentTier; }
          public int getTotalXp() { return totalXp; }
          public int getUnspentClassPoints() { return unspentClassPoints; }
          public CrewActivityState getState() { return state; }
     }
}

#!/usr/bin/env python3
# REFERENCE ONLY - old Argon draft recovered from the chat PDF. Some lines were cut off by the PDF (marked).
# Superseded by class_tree/fateweavers_class_tree.py, which builds the full, up-to-date class database.
"""
BASTION OF FATE - Master Chatlog Database & Antigravity Notebook Consolidator
Builds the queryable SQLite database (bastion_of_fate_master.db) and JSON notebook export.
"""
import sqlite3
import json
from pathlib import Path

DB_PATH = Path("bastion_of_fate_master.db")

SCHEMA_SQL = """
PRAGMA foreign_keys = ON;

-- 1. Master Exponential Class Hierarchy Table (1,031-Node Capacity: T0 -> T5)
CREATE TABLE IF NOT EXISTS character_classes (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(128) NOT NULL,
    tier INTEGER NOT NULL CHECK (tier BETWEEN 0 AND 5),
    path VARCHAR(32) NOT NULL CHECK (path IN ('NEUTRAL','MAGIC','RANGED','LIGHT_MELEE','HEAVY_MELEE','SUPPORTER')),
    parent_id VARCHAR(64) REFERENCES character_classes(id),
    unlocks_room_id VARCHAR(64),
    base_hp REAL NOT NULL DEFAULT 100.0,
    base_dmg REAL NOT NULL DEFAULT 10.0,
    attack_speed REAL NOT NULL DEFAULT 1.0,
    move_speed REAL NOT NULL DEFAULT 1.0,
    repair_mult REAL NOT NULL DEFAULT 1.0,
    manning_bonus REAL NOT NULL DEFAULT 0.15,
    can_body_block INTEGER NOT NULL DEFAULT 0,
    lock_status VARCHAR(24) NOT NULL DEFAULT 'LOCKED_BY_USER',
    tactical_mechanic TEXT NOT NULL
);

-- Covering Indexes for O(1) Runtime Promotion & Lineage Queries
CREATE INDEX IF NOT EXISTS idx_classes_parent_tier ON character_classes(parent_id, tier);
CREATE INDEX IF NOT EXISTS idx_classes_path_tier ON character_classes(path, tier);

-- 2. Fortress Room Blueprints (3 Core Starting Rooms + Class-Unlocked Chambers)
CREATE TABLE IF NOT EXISTS room_blueprints (
    room_id VARCHAR(64) PRIMARY KEY,
    display_name VARCHAR(128) NOT NULL,
    is_starting_core INTEGER NOT NULL DEFAULT 0,
    unlocked_by_class_id VARCHAR(64) REFERENCES character_classes(id),
    requires_power INTEGER NOT NULL DEFAULT 1,
    max_upgrade_tier INTEGER NOT NULL DEFAULT 4,
    slot_0_station_name VARCHAR(128) NOT NULL,
    procedural_visual_spec TEXT NOT NULL
);

-- 3. Lore & Tapestry String Codex
CREATE TABLE IF NOT EXISTS lore_codex (
    entry_id VARCHAR(64) PRIMARY KEY,
    category VARCHAR(64) NOT NULL,
    title VARCHAR(128) NOT NULL,
    summary TEXT NOT NULL
);
"""

def seed_master_database(conn: sqlite3.Connection):
    cur = conn.cursor()
    cur.executescript(SCHEMA_SQL)

     # --- SEED CORE LORE CODEX ---
     lore_entries = [
         ("LORE_TAPESTRY", "WORLD", "The Great Tapestry", "Cosmic fabric of interlocking fate-strings (Chaos, Bounty,
         ("LORE_UNSPOOLERS", "THREAT", "The Unspoolers / The Bleed", "Weeping, faceless weavers of blinding white thr  # <<< LIKELY CUT OFF IN PDF
         ("LORE_BLIND_WEAVER", "BOSS", "The Blind Weaver (The Dead Architect)", "Ancient machine at The One True Fate  # <<< LIKELY CUT OFF IN PDF
     ]
     cur.executemany("INSERT OR REPLACE INTO lore_codex VALUES (?, ?, ?, ?);", lore_entries)

     # --- SEED TIER 0, TIER 1 & TIER 2 ROOTS (31 Foundational Classes) ---
     foundational_classes = [
         # Tier 0
         ("T0_NEUTRAL", "Unclassed Survivor", 0, "NEUTRAL", None, None, 100, 10, 1.0, 1.0, 1.0, 0.0, 0, "LOCKED_BY_US  # <<< LIKELY CUT OFF IN PDF
         # Tier 1 (5 Archetypes)
         ("T1_MAGIC", "Magic User", 1, "MAGIC", "T0_NEUTRAL", None, 95, 14, 1.0, 1.0, 1.0, 0.25, 0, "LOCKED_BY_USER",
         ("T1_RANGED", "Ranged User", 1, "RANGED", "T0_NEUTRAL", None, 100, 15, 1.2, 1.1, 1.0, 0.25, 0, "LOCKED_BY_US  # <<< LIKELY CUT OFF IN PDF
         ("T1_LIGHT_MELEE", "Light Melee", 1, "LIGHT_MELEE", "T0_NEUTRAL", None, 110, 16, 1.4, 1.4, 1.1, 0.15, 0, "LO  # <<< LIKELY CUT OFF IN PDF
         ("T1_HEAVY_MELEE", "Heavy Melee", 1, "HEAVY_MELEE", "T0_NEUTRAL", None, 160, 14, 0.9, 0.85, 0.9, 0.10, 1, "L  # <<< LIKELY CUT OFF IN PDF
          ("T1_SUPPORTER", "Supporter", 1, "SUPPORTER", "T0_NEUTRAL", None, 115, 9, 1.0, 1.1, 1.75, 0.45, 0, "LOCKED_B  # <<< LIKELY CUT OFF IN PDF
          # Tier 2 (25 Specializations)
          ("T2_ELEMENTALIST", "Novice Elementalist", 2, "MAGIC", "T1_MAGIC", "ROOM_MAGE_SPIRE", 105, 18, 1.1, 1.0, 1.0  # <<< LIKELY CUT OFF IN PDF
          ("T2_SUPPORT_MAGE", "Novice Support Mage", 2, "MAGIC", "T1_MAGIC", "ROOM_MAGE_SPIRE", 115, 12, 1.0, 1.0, 1.2  # <<< LIKELY CUT OFF IN PDF
          ("T2_DARK_MAGE", "Novice Dark Mage", 2, "MAGIC", "T1_MAGIC", "ROOM_CRYPT_ALTAR", 110, 20, 1.1, 1.0, 1.0, 0.3  # <<< LIKELY CUT OFF IN PDF
          ("T2_WIZARD", "Novice Wizard", 2, "MAGIC", "T1_MAGIC", "ROOM_MAGE_SPIRE", 105, 19, 1.1, 1.0, 1.1, 0.35, 0, "  # <<< LIKELY CUT OFF IN PDF
          ("T2_ARTIFICER", "Novice Artificer", 2, "MAGIC", "T1_MAGIC", "ROOM_WORKSHOP", 125, 15, 1.0, 1.0, 1.6, 0.45,
          ("T2_BOWMAN", "Bowman", 2, "RANGED", "T1_RANGED", "ROOM_LOOKOUT_NEST", 110, 20, 1.2, 1.1, 1.0, 0.30, 0, "LOC  # <<< LIKELY CUT OFF IN PDF
          ("T2_HUNTER", "Novice Hunter", 2, "RANGED", "T1_RANGED", "ROOM_BEAST_KENNEL", 120, 17, 1.15, 1.2, 1.1, 0.30,
          ("T2_GUNSLINGER", "Gunslinger", 2, "RANGED", "T1_RANGED", "ROOM_ARMORY", 115, 22, 1.3, 1.1, 1.0, 0.35, 0, "L  # <<< LIKELY CUT OFF IN PDF
          ("T2_SLINGSHOTTER", "Slingshotter", 2, "RANGED", "T1_RANGED", None, 110, 18, 1.35, 1.2, 1.0, 0.25, 0, "LOCKE  # <<< LIKELY CUT OFF IN PDF
          ("T2_THROWER", "Hurler", 2, "RANGED", "T1_RANGED", None, 135, 21, 1.0, 1.0, 1.0, 0.25, 1, "LOCKED_BY_USER",
          ("T2_THIEF", "Thief", 2, "LIGHT_MELEE", "T1_LIGHT_MELEE", "ROOM_VAULT", 115, 18, 1.5, 1.5, 1.2, 0.25, 0, "LO  # <<< LIKELY CUT OFF IN PDF
          ("T2_SCOUT", "Scout", 2, "LIGHT_MELEE", "T1_LIGHT_MELEE", "ROOM_LOOKOUT_NEST", 120, 17, 1.4, 1.6, 1.2, 0.30,
          ("T2_ASSASSIN", "Assassin", 2, "LIGHT_MELEE", "T1_LIGHT_MELEE", None, 110, 25, 1.5, 1.4, 1.0, 0.20, 0, "LOCK  # <<< LIKELY CUT OFF IN PDF
          ("T2_BRAWLER", "Brawler", 2, "LIGHT_MELEE", "T1_LIGHT_MELEE", "ROOM_BARRACKS", 145, 20, 1.4, 1.2, 1.0, 0.15,
          ("T2_DUELIST", "Duelist", 2, "LIGHT_MELEE", "T1_LIGHT_MELEE", "ROOM_BARRACKS", 125, 22, 1.45, 1.3, 1.0, 0.20  # <<< LIKELY CUT OFF IN PDF
          ("T2_CROG", "Crog", 2, "HEAVY_MELEE", "T1_HEAVY_MELEE", None, 210, 24, 0.8, 0.85, 0.7, 0.05, 1, "LOCKED_BY_U  # <<< LIKELY CUT OFF IN PDF
          ("T2_SQUIRE", "Squire", 2, "HEAVY_MELEE", "T1_HEAVY_MELEE", "ROOM_BARRACKS", 175, 18, 1.0, 0.95, 1.1, 0.25,
          ("T2_PALADIN", "Initiate Paladin", 2, "HEAVY_MELEE", "T1_HEAVY_MELEE", "ROOM_SANCTUARY", 185, 19, 0.95, 0.95  # <<< LIKELY CUT OFF IN PDF
          ("T2_HAMMERMAN", "Hammerman", 2, "HEAVY_MELEE", "T1_HEAVY_MELEE", "ROOM_FORGE", 190, 23, 0.85, 0.9, 1.3, 0.2  # <<< LIKELY CUT OFF IN PDF
          ("T2_SHIELDBEARER", "Shieldbearer", 2, "HEAVY_MELEE", "T1_HEAVY_MELEE", "ROOM_GATEHOUSE", 220, 14, 0.85, 0.8  # <<< LIKELY CUT OFF IN PDF
          ("T2_MEDIC", "Medic", 2, "SUPPORTER", "T1_SUPPORTER", None, 125, 10, 1.0, 1.15, 1.4, 0.50, 0, "LOCKED_BY_USE  # <<< LIKELY CUT OFF IN PDF
          ("T2_HANDYMAN", "Handyman", 2, "SUPPORTER", "T1_SUPPORTER", "ROOM_WORKSHOP", 135, 12, 1.0, 1.1, 2.2, 0.55, 0  # <<< LIKELY CUT OFF IN PDF
          ("T2_MYSTIC", "Novice Mystic", 2, "SUPPORTER", "T1_SUPPORTER", None, 115, 13, 1.0, 1.1, 1.3, 0.55, 0, "LOCKE  # <<< LIKELY CUT OFF IN PDF
          ("T2_ALCHEMIST", "Novice Alchemist", 2, "SUPPORTER", "T1_SUPPORTER", "ROOM_ALCHEMIST_LAB", 120, 14, 1.0, 1.0  # <<< LIKELY CUT OFF IN PDF
          ("T2_JESTER", "Jester", 2, "SUPPORTER", "T1_SUPPORTER", "ROOM_TAVERN", 120, 13, 1.25, 1.3, 1.2, 0.45, 0, "LO  # <<< LIKELY CUT OFF IN PDF
     ]
     cur.executemany("""
         INSERT OR REPLACE INTO character_classes
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);
     """, foundational_classes)

     # --- SEED THE 3 CORE STARTING ROOMS + CLASS-UNLOCKED ROOM SOCKETS ---
     rooms = [
         ("ROOM_WEAPONS_TOWER", "Weapons Tower", 1, None, 1, 4, "Artillery Gunner Console",
          "Core Starting Room #1: Animated dual loading rails, recoil hydraulics, and targetingholo-reticle."),
         ("ROOM_CHRYSALIS_WARD", "The Chrysalis Ward", 1, None, 1, 4, "Crucible & Bio-Vat Console",
          "Core Starting Room #2: Central emerald bio-suspension vat, rising bubble particles, and class promotion ri  # <<< LIKELY CUT OFF IN PDF
         ("ROOM_FATEWEAVER_LOOM", "The Fateweaver Loom", 1, None, 1, 4, "Spindle Navigator Console",
          "Core Starting Room #3: Concentric spinning bronze/gold rings, taut fate-threads, and strain safety vents."  # <<< LIKELY CUT OFF IN PDF
         ("ROOM_MAGE_SPIRE", "Mage Spire", 0, "T2_ELEMENTALIST", 1, 4, "Arcane Ward Lectern",
          "Unlocked by Magic classes: Projects rechargeable energy barrier layers over the fortress."),
         ("ROOM_ALCHEMIST_LAB", "Alchemist Lab", 0, "T2_ALCHEMIST", 1, 3, "Distillation Alembic",
          "Unlocked by Alchemist classes: Passively brews healing panaceas and volatile acid/fire flasks."),
         ("ROOM_WORKSHOP", "Artificer Workshop", 0, "T2_ARTIFICER", 1, 3, "Clockwork Golem Gantry",
          "Unlocked by Artificer/Handyman classes: Fabricates autonomous repair mites and custom turrets."),
         ("ROOM_BARRACKS", "Barracks & Drill Hall", 0, "T2_SQUIRE", 0, 2, "Tactical War-Table",
          "Unlocked by Melee classes: Passively buffs defender combat stats and armor integrity.")
     ]
     cur.executemany("INSERT OR REPLACE INTO room_blueprints VALUES (?,?,?,?,?,?,?,?);", rooms)
     conn.commit()

if __name__ == "__main__":
    with sqlite3.connect(DB_PATH) as conn:
        seed_master_database(conn)
        print(f"Master SQLite Database initialized at: {DB_PATH.resolve()}")

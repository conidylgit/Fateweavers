// REFERENCE ONLY - old Argon/Gemini LibGDX draft recovered from the chat PDF.
// Does NOT compile on its own: it depends on engine files that were never fully in the chat logs,
// some long lines were cut off by the PDF (marked where detected), and it uses old class names.
// Source of truth for classes: class_tree/fateweavers_class_tree.py

package com.bastionoffate.db;

import com.bastionoffate.classes.ClassTreeDefinitions.ArchetypePath;
import com.bastionoffate.classes.ClassTreeDefinitions.CharacterClassNode;
import com.bastionoffate.classes.ClassTreeDefinitions.StatBlock;
import java.sql.*;
import java.util.*;
public class ClassTreeRepository {

     private final String jdbcUrl;
     private final Map<String, CharacterClassNode> cacheById = new LinkedHashMap<>();
     private final Map<String, List<CharacterClassNode>> childrenByParentId = new HashMap<>();

     public ClassTreeRepository(String sqliteFilePath) {
         this.jdbcUrl = "jdbc:sqlite:" + sqliteFilePath;
     }

     public void loadAllClassesIntoMemory() throws SQLException {
         cacheById.clear();
         childrenByParentId.clear();
         String sql = """
              SELECT id, name, tier, path, parent_id, unlocks_room_id,
                     base_hp, base_dmg, attack_speed, move_speed, repair_mult, manning_bonus, tactical_mechanic  /* <<< LIKELY CUT OFF IN PDF */
              FROM character_classes
              ORDER BY tier ASC, id ASC;
         """;
         try (Connection conn = DriverManager.getConnection(jdbcUrl);
               PreparedStatement stmt = conn.prepareStatement(sql);
               ResultSet rs = stmt.executeQuery()) {
              while (rs.next()) {
                  StatBlock stats = new StatBlock(
                          rs.getFloat("base_hp"),
                          rs.getFloat("base_dmg"),
                          rs.getFloat("attack_speed"),
                          rs.getFloat("move_speed"),
                          rs.getFloat("repair_mult"),
                          rs.getFloat("manning_bonus")
                  );
                  CharacterClassNode node = new CharacterClassNode(
                          rs.getString("id"),
                          rs.getString("name"),
                          rs.getInt("tier"),
                          ArchetypePath.valueOf(rs.getString("path")),
                          rs.getString("parent_id"),
                          rs.getString("unlocks_room_id"),
                          stats,
                          rs.getString("tactical_mechanic")
                  );
                  cacheById.put(node.id(), node);
                  if (node.parentId() != null) {
                      childrenByParentId.computeIfAbsent(node.parentId(), k -> new ArrayList<>()).add(node);
                  }
              }
         }
     }

     public CharacterClassNode getById(String classId) {
         return cacheById.get(classId);
     }

     public List<CharacterClassNode> getAvailablePromotions(String currentClassId, int maxUnlockedTier) {
         List<CharacterClassNode> children = childrenByParentId.getOrDefault(currentClassId, Collections.emptyList())
         return children.stream().filter(c -> c.tier() <= maxUnlockedTier).toList();
     }
}

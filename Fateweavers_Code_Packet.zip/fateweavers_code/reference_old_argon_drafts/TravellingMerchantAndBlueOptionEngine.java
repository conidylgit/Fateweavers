// REFERENCE ONLY - old Argon/Gemini LibGDX draft recovered from the chat PDF.
// Does NOT compile on its own: it depends on engine files that were never fully in the chat logs,
// some long lines were cut off by the PDF (marked where detected), and it uses old class names.
// Source of truth for classes: class_tree/fateweavers_class_tree.py

package com.bastionoffate.events;

import com.bastionoffate.combat.SiegeArtilleryEngine.MagicalTurretWeapon;
import com.bastionoffate.Events.FateEncounterEngine.EventChoice;
import com.bastionoffate.events.FateEncounterEngine.FateEncounterEvent;
import java.util.*;

public class TravellingMerchantAndBlueOptionEngine {

     private static final Set<String> TURRET_CRAFTER_CLASSES = Set.of(
             "T3_RUNESMITH", "T4_GUNSMITH", "T4_MASTER_ARTIFICER",
             "T4_RESEARCH_AND_DEV", "T5_ARTISANAL_CANNONEER", "T5_HYPERFIXATED_GUN_NERD",
             "T5_ATOM_SPLITTER", "T5_EXPERIMENTAL_WEAPONS_DEPT"
     );
     /**
       * Filters an encounter's choices in O(1) per choice based on the active crew's class IDs.
       */
     public List<EventChoice> evaluateUnlockedChoices(FateEncounterEvent event, Set<String> activeCrewClassIds) {
          List<EventChoice> unlocked = new ArrayList<>();
          for (EventChoice choice : event.choices()) {
              if (!choice.isBlueOption() || activeCrewClassIds.contains(choice.requiredClassId())) {
                  unlocked.add(choice);
              }
          }
          return unlocked;
     }

     /**
      * Allows players who invested in the Artificer/Runesmith/Gunsmith branch to craft
      * FTL-style Fortress Turrets directly from raw scrap without needing a Travelling Merchant node.
      */
     public Optional<MagicalTurretWeapon> craftTurretViaArtificerBranch(
             String weaponPresetId, int currentScrap, Set<String> activeCrewClassIds) {

          boolean hasCrafter = activeCrewClassIds.stream().anyMatch(TURRET_CRAFTER_CLASSES::contains);
          if (!hasCrafter) return Optional.empty();

          return switch (weaponPresetId) {
              case "WPN_FIRE_ORB_TURRET" -> currentScrap >= 40
                      ? Optional.of(MagicalTurretWeapon.createMagicalFireOrbTurret())
                      : Optional.empty();
              case "WPN_RUNE_RAIL_CANNON" -> currentScrap >= 65
                      ? Optional.of(MagicalTurretWeapon.createRuneboundRailCannon())
                      : Optional.empty();
              case "WPN_RND_DOOM_MORTAR" -> (currentScrap >= 90 && activeCrewClassIds.contains("T4_RESEARCH_AND_DEV"))
                      ? Optional.of(MagicalTurretWeapon.createRnDApocalypseMortar())
                      : Optional.empty();
              default -> Optional.empty();
          };
     }
}

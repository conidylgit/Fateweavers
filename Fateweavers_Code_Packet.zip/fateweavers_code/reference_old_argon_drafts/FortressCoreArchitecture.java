// REFERENCE ONLY - old Argon/Gemini LibGDX draft recovered from the chat PDF.
// Does NOT compile on its own: it depends on engine files that were never fully in the chat logs,
// some long lines were cut off by the PDF (marked where detected), and it uses old class names.
// Source of truth for classes: class_tree/fateweavers_class_tree.py

package com.bastionoffate.fortress;

import java.awt.Point;
import java.awt.Rectangle;
import java.util.*;

/**
 * Enforces the 3 Core Starting Rooms (Weapons Tower, Chrysalis Ward, The Fateweaver Loom)
 * and provides socketed expansion slots for rooms unlocked via the Class Tree.
 */
public class FortressCoreArchitecture {

     public enum CoreRoomType {
         // THE 3 CORE STARTING ROOMS (Always present from Day 1)
         WEAPONS_TOWER("ROOM_WEAPONS_TOWER", "Weapons Tower", true, true, 4, null),
         CHRYSALIS_WARD("ROOM_CHRYSALIS_WARD", "The Chrysalis Ward", true, true, 4, null),
         FATEWEAVER_LOOM("ROOM_FATEWEAVER_LOOM", "The Fateweaver Loom", true, true, 4, null),

          // SOCKETED EXPANSION ROOMS (Unlocked dynamically when crew reach specific classes)
          EMPTY_SOCKET("ROOM_EMPTY_SOCKET", "Unbuilt Chamber Socket", false, false, 1, null),
          MAGE_SPIRE("ROOM_MAGE_SPIRE", "Mage Spire (Barrier Wards)", false, true, 4, "T2_ELEMENTALIST"),
          ALCHEMIST_LAB("ROOM_ALCHEMIST_LAB", "Alchemist Lab", false, true, 3, "T2_ALCHEMIST"),
          ARTIFICER_WORKSHOP("ROOM_WORKSHOP", "Artificer Workshop", false, true, 3, "T2_ARTIFICER"),
          BARRACKS("ROOM_BARRACKS", "Barracks & Drill Hall", false, false, 2, "T2_SQUIRE");

          private final String id;
          private final String displayName;
          private final boolean startingCore;
          private final boolean requiresPower;
          private final int maxUpgradeTier;
          private final String unlockedByClassId;

          CoreRoomType(String id, String displayName, boolean startingCore,
                       boolean requiresPower, int maxUpgradeTier, String unlockedByClassId) {
              this.id = id;
              this.displayName = displayName;
              this.startingCore = startingCore;
              this.requiresPower = requiresPower;
              this.maxUpgradeTier = maxUpgradeTier;
              this.unlockedByClassId = unlockedByClassId;
          }

          public String getId() { return id; }
          public String getDisplayName() { return displayName; }
          public boolean isStartingCore() { return startingCore; }
          public boolean isRequiresPower() { return requiresPower; }
          public int getMaxUpgradeTier() { return maxUpgradeTier; }
          public String getUnlockedByClassId() { return unlockedByClassId; }
     }

     public static classModularRoom {
         private final String instanceId;
         private final int gridX, gridY;
         private CoreRoomType type;
         private int upgradeTier = 1;
         private int allocatedPower = 0;
         private float structuralIntegrity = 100f;
         private float fireIntensity = 0f;
         private int activeBreaches = 0;
         private final Rectangle pixelBounds;
         private final Point[] quadrantPads = new Point[4];
         private final String[] padOccupantUnitIds = new String[4];

          // Room-Specific Procedural Animation Timers
          private floatloomSpindleAngle = 0f;
          private float chrysalisBubblePhase = 0f;
          private float weaponsRecoilOffset = 0f;

          public ModularRoom(String instanceId, int gridX, int gridY, CoreRoomType type, int originX, int originY, int  /* <<< LIKELY CUT OFF IN PDF */
              this.instanceId = Objects.requireNonNull(instanceId);
              this.gridX = gridX;
              this.gridY = gridY;
              this.type = Objects.requireNonNull(type);
              int rx = originX + gridX * w;
              int ry = originY + gridY * h;
              this.pixelBounds = new Rectangle(rx, ry, w, h);

                int padOffsetX = 54, padOffsetY = 52;
                quadrantPads[0] = new Point(rx + padOffsetX, ry + padOffsetY);                        // Top-Left (Primary Operator  /* <<< LIKELY CUT OFF IN PDF */
                quadrantPads[1] = new Point(rx + w - padOffsetX, ry + padOffsetY);                    // Top-Right  /* <<< LIKELY CUT OFF IN PDF */
                quadrantPads[2] = new Point(rx + padOffsetX, ry + h - padOffsetY);                    // Bottom-Left  /* <<< LIKELY CUT OFF IN PDF */
                quadrantPads[3] = new Point(rx + w - padOffsetX, ry + h - padOffsetY);                // Bottom-Right  /* <<< LIKELY CUT OFF IN PDF */
          }

          public boolean isOperational() {
              return structuralIntegrity > 0f && (!type.isRequiresPower() || allocatedPower > 0);
          }

          public void tickVisualAnimations(float deltaSeconds, float manningMultiplier) {
              if (!isOperational()) return;
              float speed = deltaSeconds * manningMultiplier * (1.0f + 0.25f * allocatedPower);
              switch (type) {
                  case FATEWEAVER_LOOM -> loomSpindleAngle = (loomSpindleAngle + speed * 95f) % 360f;
                  case CHRYSALIS_WARD -> chrysalisBubblePhase += speed * 4.0f;
                  case WEAPONS_TOWER -> weaponsRecoilOffset = Math.max(0f, weaponsRecoilOffset - deltaSeconds * 18f);
                  default -> {}
              }
          }

          public void triggerArtilleryRecoil() {
              this.weaponsRecoilOffset = 14.0f;
          }

          public boolean constructUnlockedRoom(CoreRoomType newType, Set<String> unlockedClassIds) {
              if (this.type != CoreRoomType.EMPTY_SOCKET) return false;
              if (newType.getUnlockedByClassId() != null && !unlockedClassIds.contains(newType.getUnlockedByClassId())
                  return false;
              }
              this.type = newType;
              this.upgradeTier = 1;
              return true;
          }

          public String getInstanceId() { return instanceId; }
          public int getGridX() { return gridX; }
          public int getGridY() { return gridY; }
          public CoreRoomType getType() { return type; }
          public int getUpgradeTier() { return upgradeTier; }
          public void setUpgradeTier(int tier) { this.upgradeTier = Math.min(type.getMaxUpgradeTier(), tier); }
          public int getAllocatedPower() { return allocatedPower; }
          public void setAllocatedPower(int p) { this.allocatedPower = p; }
          public float getStructuralIntegrity() { return structuralIntegrity; }
          public void setStructuralIntegrity(float hp) { this.structuralIntegrity = Math.max(0f, Math.min(100f, hp));
          public float getFireIntensity() { return fireIntensity; }
          public void setFireIntensity(float f) { this.fireIntensity = Math.max(0f, Math.min(100f, f)); }
          public int getActiveBreaches() { return activeBreaches; }
          public void setActiveBreaches(int b) { this.activeBreaches = Math.max(0, b); }
          public Rectangle getPixelBounds() { return pixelBounds; }
          public Point[] getQuadrantPads() { return quadrantPads; }
          public String[] getPadOccupantUnitIds() { return padOccupantUnitIds; }
          public float getLoomSpindleAngle() { return loomSpindleAngle; }
          public float getChrysalisBubblePhase() { return chrysalisBubblePhase; }
          public float getWeaponsRecoilOffset() { return weaponsRecoilOffset; }
     }
}

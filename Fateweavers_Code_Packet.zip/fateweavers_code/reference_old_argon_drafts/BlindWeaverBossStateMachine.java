// REFERENCE ONLY - old Argon/Gemini LibGDX draft recovered from the chat PDF.
// Does NOT compile on its own: it depends on engine files that were never fully in the chat logs,
// some long lines were cut off by the PDF (marked where detected), and it uses old class names.
// Source of truth for classes: class_tree/fateweavers_class_tree.py

package com.bastionoffate.boss;

import com.bastionoffate.combat.CrewStateMachineAndXpPipeline.CrewAgent;
import com.bastionoffate.fortress.FortressCoreArchitecture.ModularRoom;
import java.util.*;

public class BlindWeaverBossStateMachine {

     public enum WeaverPhase {
         PHASE_1_STATIC_SPINDLE,      // Emits Stagnation Pulses that drain Fateweaver Loom charge
         PHASE_2_BRONZE_NEEDLE_SWARM, // Launches weeping white-thread Unspoolers into core rooms
         PHASE_3_UNBENDING_THREAD,    // Fires Predetermination Waves that attempt to de-class crew to Tier 0  /* <<< LIKELY CUT OFF IN PDF */
         CLEANSED_ONE_TRUE_FATE       // Victory state: free will preserved
     }

     private static final Set<String> FATE_ANCHOR_COUNTERS = Set.of(
             "T4_REALITY_ANCHOR", "T4_TIME_MAGE", "T4_THREAD_SPINNER",
             "T5_THE_CLOCKMAKER", "T5_THE_WATCHER", "T5_UNSHACKLED_SOVEREIGN",
             "T5_DESCENDED_DEITY", "T5_INHABITANT_OF_THE_IMPOSSIBLE"
     );

     private WeaverPhase phase = WeaverPhase.PHASE_1_STATIC_SPINDLE;
     private float hull = 500f;
     private float maxHull = 500f;
     private int spindleBarriers = 4;
     private float abilityTimer = 0f;

     public String tickBossEncounter(float deltaSeconds,
                                     ModularRoom loomRoom,
                                     List<CrewAgent> playerCrew,
                                     Set<String> activeCrewClassIds) {
         if (phase == WeaverPhase.CLEANSED_ONE_TRUE_FATE) return "CLEANSED";

          abilityTimer += deltaSeconds;
          if (abilityTimer < 10.0f) return null;
          abilityTimer = 0f;

          return switch (phase) {
                case PHASE_1_STATIC_SPINDLE -> {
                    loomRoom.setAllocatedPower(Math.max(0, loomRoom.getAllocatedPower() - 1));
                    yield "STAGNATION PULSE: The Blind Weaver drains 1 Power from The Fateweaver Loom!";
                }
                case PHASE_2_BRONZE_NEEDLE_SWARM -> {
                    loomRoom.setActiveBreaches(loomRoom.getActiveBreaches() + 1);
                    yield "BRONZE-NEEDLE BREACH: Weeping white-thread Unspoolers tear into the Bastion!";
                }
                case PHASE_3_UNBENDING_THREAD -> {
                    boolean hasFateAnchor = activeCrewClassIds.stream().anyMatch(FATE_ANCHOR_COUNTERS::contains);
                    if (hasFateAnchor) {
                        yield "PREDETERMINATION COUNTERED! Your Fate-Anchor crew member deflected the timeline wipe!";
                    }
                    if (!playerCrew.isEmpty()) {
                        CrewAgent victim = playerCrew.get(0);
                        String prevClass = victim.getCurrentClassId();
                        victim.forceRevertClass("T0_NEUTRAL", 0);
                        yield "PREDETERMINATION WAVE: " + victim.getName() + " was overwritten from " + prevClass + " ba  /* <<< LIKELY CUT OFF IN PDF */
                    }
                    yield "PREDETERMINATION WAVE: Reality trembles!";
                }
                case CLEANSED_ONE_TRUE_FATE -> "CLEANSED";
          };
     }

     public void applyArtilleryDamage(float dmg, boolean piercesBarriers) {
         if (!piercesBarriers && spindleBarriers > 0) {
             spindleBarriers--;
             return;
         }
         hull = Math.max(0f, hull - dmg);
         if (hull <= 0f) {
             switch (phase) {
                 case PHASE_1_STATIC_SPINDLE -> {
                     phase = WeaverPhase.PHASE_2_BRONZE_NEEDLE_SWARM;
                     maxHull = 650f; hull = maxHull; spindleBarriers = 5;
                 }
                 case PHASE_2_BRONZE_NEEDLE_SWARM -> {
                     phase = WeaverPhase.PHASE_3_UNBENDING_THREAD;
                     maxHull = 800f; hull = maxHull; spindleBarriers = 6;
                 }
                 case PHASE_3_UNBENDING_THREAD -> {
                     phase = WeaverPhase.CLEANSED_ONE_TRUE_FATE;
                     hull = 0f; spindleBarriers = 0;
                 }
                 case CLEANSED_ONE_TRUE_FATE -> {}
             }
         }
     }

     public WeaverPhase getPhase() { return phase; }
     public float getHull() { return hull; }
     public int getSpindleBarriers() { return spindleBarriers; }
}

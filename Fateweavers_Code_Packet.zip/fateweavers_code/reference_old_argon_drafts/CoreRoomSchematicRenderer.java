// REFERENCE ONLY - old Argon/Gemini LibGDX draft recovered from the chat PDF.
// Does NOT compile on its own: it depends on engine files that were never fully in the chat logs,
// some long lines were cut off by the PDF (marked where detected), and it uses old class names.
// Source of truth for classes: class_tree/fateweavers_class_tree.py

package com.bastionoffate.ui;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.bastionoffate.fortress.FortressCoreArchitecture.CoreRoomType;
import com.bastionoffate.fortress.FortressCoreArchitecture.ModularRoom;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.List;

public class CoreRoomSchematicRenderer {

     private static final Color STONE_WALL_OUTER = new Color(0.45f, 0.42f, 0.39f, 1f);
     private static final Color OUTLINE_DARK     = new Color(0.08f, 0.06f, 0.08f, 1f);
     private static final Color LOOM_GOLD        = new Color(0.95f, 0.78f, 0.28f, 1f);
     private static final Color LOOM_CYAN        = new Color(0.32f, 0.82f, 0.98f, 1f);
     private static final Color CHRYSALIS_GREEN = new Color(0.24f, 0.88f, 0.55f, 1f);
     private static final Color ARTILLERY_BRASS = new Color(0.82f, 0.55f, 0.22f, 1f);

     public void renderFortressRooms(ShapeRenderer shapes, SpriteBatch batch, BitmapFont font, List<ModularRoom> room  /* <<< LIKELY CUT OFF IN PDF */
         // PASS 1: Filled Room Interiors, Quadrant Pads & Room-Specific Machinery
         shapes.begin(ShapeRenderer.ShapeType.Filled);
         for (ModularRoom room : rooms) {
             Rectangle b = room.getPixelBounds();

                // 1. Base Floor Fill (Tinted by room archetype & structural damage)
                float dmgRatio = 1.0f - (room.getStructuralIntegrity() / 100f);
                shapes.setColor(0.18f + dmgRatio * 0.35f, 0.17f, 0.19f, 1f);
                shapes.rect(b.x, b.y, b.width, b.height);

                // 2. Quadrant Sub-Slot Pads (4 clickable non-overlapping crew stations per room)
                Point[] pads = room.getQuadrantPads();
                for (int i = 0; i < pads.length; i++) {
                    shapes.setColor(i == 0 ? new Color(0.22f, 0.32f, 0.38f, 1f) : new Color(0.13f, 0.12f, 0.14f, 1f));
                    shapes.ellipse(pads[i].x - 22f, pads[i].y - 10f, 44f, 20f);
                }

                // 3. Dispatch Procedural Centerpiece Graphics for the 3 Core Starting Rooms
                int cx = b.x + b.width / 2;
                int cy = b.y + b.height / 2;
                switch (room.getType()) {
                    case WEAPONS_TOWER -> drawWeaponsTowerInterior(shapes, room, cx, cy);
                    case CHRYSALIS_WARD -> drawChrysalisWardInterior(shapes, room, cx, cy);
                    case FATEWEAVER_LOOM -> drawFateweaverLoomInterior(shapes, room, cx, cy);
                    case EMPTY_SOCKET -> drawEmptySocketInterior(shapes, cx, cy);
                    default -> drawUnlockedModuleInterior(shapes, cx, cy);
                }

                // 4. Power Allocation Pips (Bottom-Left Corner)
                if (room.getType().isRequiresPower()) {
                    for (int p = 0; p < room.getType().getMaxUpgradeTier(); p++) {
                        shapes.setColor(p < room.getAllocatedPower() ? CHRYSALIS_GREEN : Color.DARK_GRAY);
                        shapes.rect(b.x + 12f + p * 16f, b.y + 10f, 12f, 10f);
                    }
                }
          }
          shapes.end();

          // PASS 2: Crisp Blueprint Schematic Line-Work, Spinning Loom Threads & Wall Borders
          shapes.begin(ShapeRenderer.ShapeType.Line);
          for (ModularRoom room : rooms) {
              Rectangle b = room.getPixelBounds();
              shapes.setColor(STONE_WALL_OUTER);
              shapes.rect(b.x, b.y, b.width, b.height);
              shapes.setColor(OUTLINE_DARK);
              shapes.rect(b.x + 4f, b.y + 4f, b.width - 8f, b.height - 8f);

                if (room.getType() == CoreRoomType.FATEWEAVER_LOOM) {
                    drawFateweaverLoomThreads(shapes, room, b.x + b.width / 2f, b.y + b.height / 2f);
                }
          }
          shapes.end();

          // PASS 3: Typography & Station Readouts
          batch.begin();
          for (ModularRoom room : rooms) {
              Rectangle b = room.getPixelBounds();
              font.setColor(LOOM_GOLD);
              font.draw(batch, room.getType().getDisplayName() + " [Lv." + room.getUpgradeTier() + "]", b.x + 14f, b.y  /* <<< LIKELY CUT OFF IN PDF */
          }
          batch.end();
     }

     private void drawWeaponsTowerInterior(ShapeRenderer shapes, ModularRoom room, float cx, float cy) {
         float recoil = room.getWeaponsRecoilOffset();
         // Artillery Turntable Base
         shapes.setColor(0.25f, 0.23f, 0.22f, 1f);
         shapes.circle(cx, cy, 34f);
         // Dual Brass Loading Rails
         shapes.setColor(ARTILLERY_BRASS);
         shapes.rect(cx - 18f, cy - 28f, 6f, 56f);
         shapes.rect(cx + 12f, cy - 28f, 6f, 56f);
         // Recoiling Heavy Cannon Breech & Barrel
         shapes.setColor(0.38f, 0.40f, 0.45f, 1f);
         shapes.rect(cx - 12f, cy - 16f - recoil, 24f, 48f);
         // Glowing Arcane Fire-Orb Chamber Core
         shapes.setColor(room.isOperational() ? new Color(0.98f, 0.42f, 0.15f, 1f) : Color.DARK_GRAY);
         shapes.circle(cx, cy - recoil, 9f);
     }

     private void drawChrysalisWardInterior(ShapeRenderer shapes, ModularRoom room, float cx, float cy) {
         float phase = room.getChrysalisBubblePhase();
         // Outer Crucible Pedestal Ring
         shapes.setColor(0.20f, 0.32f, 0.28f, 1f);
         shapes.circle(cx, cy, 36f);
         // Central Bio-Suspension Vat
         shapes.setColor(room.isOperational() ? CHRYSALIS_GREEN : new Color(0.15f, 0.30f, 0.22f, 1f));
         shapes.circle(cx, cy, 24f);
         // Rising Procedural Bio-Bubbles inside the Vat
         if (room.isOperational()) {
             shapes.setColor(0.85f, 1.0f, 0.92f, 1f);
             for (int b = 0; b < 4; b++) {
                 float bx = cx + MathUtils.sin(phase + b * 1.7f) * 11f;
                 float by = cy - 14f + ((phase * 8f + b * 7f) % 28f);
                 shapes.circle(bx, by, 3.5f);
             }
         }
     }

     private void drawFateweaverLoomInterior(ShapeRenderer shapes, ModularRoom room, float cx, float cy) {
         // Sunken Octagonal Loom Pit
         shapes.setColor(0.10f, 0.09f, 0.16f, 1f);
         shapes.circle(cx, cy, 38f);
         // Glowing Mana Core Ring
         shapes.setColor(room.isOperational() ? LOOM_CYAN : Color.DARK_GRAY);
         shapes.circle(cx, cy, 16f);
         // Central Bronze Spindle Hub
         shapes.setColor(LOOM_GOLD);
         shapes.circle(cx, cy, 7f);
     }

     private void drawFateweaverLoomThreads(ShapeRenderer shapes, ModularRoom room, float cx, float cy) {
         float angleDeg = room.getLoomSpindleAngle();
         shapes.setColor(LOOM_GOLD);
         for (int i = 0; i < 8; i++) {
             float rad = MathUtils.degreesToRadians * (angleDeg + i * 45f);
             float tx = cx + MathUtils.cos(rad) * 36f;
             float ty = cy + MathUtils.sin(rad) * 36f;
             shapes.line(cx, cy, tx, ty);
         }
         shapes.setColor(LOOM_CYAN);
         shapes.circle(cx, cy, 28f);
     }

     private void drawEmptySocketInterior(ShapeRenderer shapes, float cx, float cy) {
         shapes.setColor(0.14f, 0.14f, 0.15f, 1f);
         shapes.rect(cx - 26f, cy - 26f, 52f, 52f);
     }

     private void drawUnlockedModuleInterior(ShapeRenderer shapes, float cx, float cy) {
         shapes.setColor(LOOM_CYAN);
         shapes.circle(cx, cy, 22f);
     }
}

# Fateweavers — Code Packet (23 Oct 2026)

All the code from the Gemini/Argon chats, sorted into what's current and what's reference only.

## ⚠️ Read this first
The chat PDFs **cut off every code line that ran past the edge of the page**. Code copied straight out of the PDFs won't compile. Everything here has been handled:
- **Current code** was repaired and tested.
- **Reference code** is marked where lines were cut off.

The full source of Argon's early engines (`FateLoomEngine`, `FortressSubsystemEngine`, `BoardingAndPathfindingEngine`, `SiegeArtilleryEngine`, `FateEncounterEngine`, `ClassTreeDefinitions`…) was **never fully in the chat logs**, only small patches. So it can't be recovered from the PDFs. If you have those files saved anywhere, they're the only copy.

---

## 1. `Fateweavers.java`: the current prototype ✅
**Module 1: Living Fortress & Character Sandbox.** This is the latest code, written after you switched to building one module at a time.

- **Run:** `java Fateweavers.java` (Java 17+, no other files needed).
- **Status:** compiles, and has been tested rendering and moving a character.
- **Repairs:** about 40 cut-off lines were rebuilt (listed at the top of the file). The class descriptions and a few popup messages are reworded, because the originals were cut off mid-sentence.
- **Controls:**
  - Left-click a person to select them (works even when several people share a room).
  - Right-click a room pad to walk there (pathfinds through doors).
  - Left-click a door to cycle Auto → Held Open → Locked.
  - Keys 1–4 select crew.
  - Bottom buttons swap the selected person between Unclassed and the 5 basic classes.
- **Note:** the room layout is the older 8-room one (Mage Spire, Barracks, Gatehouse, Fate Loom Hall, Chrysalis Ward, Artificer Study, Granary, Alchemist Lab). It was written **before** you decided on the 3 core starting rooms (Weapons Tower, Chrysalis Ward, Fateweaver Loom). Updating it is a good first task in the new project.

## 2. `class_tree/`: the up-to-date class database ✅
This **replaces** the old `seed_locked_classes.sql`, `seed_remaining_143_classes.sql`, `seed_tier5_*.sql` files, which contain outdated draft names (e.g. "Giga-Crog", "Knuckle-Duster Danny").

| File | What it is |
|---|---|
| `fateweavers_class_tree.py` | The master tree as editable Python data. Run `python fateweavers_class_tree.py` to rebuild the other three files. It also checks the branching (5/5/4/3/2) and stops if a branch has the wrong number of children. |
| `fateweavers_class_tree.json` | Every class: `id, name, tier, path, parent_id, status` |
| `fateweavers_class_tree.sql` | SQLite table + inserts |
| `fateweavers.db` | Ready-made SQLite database |

- **Count:** 551 classes (1 + 5 + 25 + 100 + 300 + 120 Magic Tier 5s). The remaining 480 Tier 5s get added as you name them.
- **Matches the info packet exactly:** every name was checked against it.
- **`status: "check"`:** marks the 7 names the packet flags as unconfirmed (Battlemage, Blowgunner, Pruner, the three Smith T4s, Vessel of the Nameless Void).
- **Names only:** stats and mechanics aren't included, since those were never decided.

## 3. `reference_old_argon_drafts/`: reference only ⚠️
Argon's last big LibGDX architecture output ("5 directives" prompt):
- `FortressCoreArchitecture` (3 core rooms + unlockable room sockets)
- `ClassTreeRepository`
- `CoreRoomSchematicRenderer` (procedural Weapons Tower / Chrysalis Ward / Fateweaver Loom art)
- `OptimizationEngine` (particle pooling, path cache, hazard tracking)
- `CrewStateMachineAndXpPipeline`
- `TravellingMerchantAndBlueOptionEngine`
- `BlindWeaverBossStateMachine` (3 phases)
- `bastion_notebook_db.py`

These are useful as **design ideas**, but they don't compile. They depend on the missing engine files, still use `com.bastionoffate` naming, and some lines were cut off (marked `LIKELY CUT OFF IN PDF`).

**Not included:** the earlier all-in-one Swing prototype (Loom map, siege combat, Chrysalis tree view). Module 1 replaced it, and it had the same cut-off problem.

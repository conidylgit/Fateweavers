import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.*;
import java.util.List;

/**
 * FATEWEAVERS - MODULE 1: THE LIVING FORTRESS & CHARACTER SANDBOX
 * Run directly via: java Fateweavers.java   (Java 17+)
 *
 * Recovered from the Gemini chat PDF (23 Oct 2026). The PDF cut off ~40 long lines; they were
 * rebuilt so the file compiles and runs. Rebuilt parts: the 6 class description strings, a few
 * status/popup messages, method signatures, and the dash pattern / fade alpha values.
 * Everything else is the original code. Title text renamed from "Bastion of Fate" to "Fateweavers".
 */
public class Fateweavers extends JPanel implements ActionListener {

    private static final int WIDTH = 1360;
    private static final int HEIGHT = 840;

    // --- PALETTE (Warm Stone Interior & Sprite Shading) ---
    private static final Color BG_DARK = new Color(22, 20, 24);
    private static final Color OUTLINE_BLACK = new Color(20, 16, 19);
    private static final Color SKIN_LIGHT = new Color(245, 193, 150);
    private static final Color SKIN_SHADE = new Color(212, 149, 106);
    private static final Color GOLD_ACCENT = new Color(240, 195, 75);
    private static final Color CYAN_SELECT = new Color(85, 215, 255);

    // --- THE UNCLASSED + 5 BASIC CLASSES ---
    public enum BasicClass {
        UNCLASSED("Unclassed", new Color(224, 122, 46), new Color(179, 89, 26), "Standard jumpsuit survivor; no specialisation yet. Earns XP doing anything."),
        MAGIC("Magic User", new Color(88, 101, 242), new Color(56, 65, 175), "Arcane tunic & floating mana orb; powers magical stations faster."),
        RANGED("Ranged User", new Color(67, 160, 71), new Color(42, 112, 46), "Ranger cloak & recurve bow; mans defensive weapon stations."),
        LIGHT_MELEE("Light Melee", new Color(211, 47, 47), new Color(148, 27, 27), "Agile crimson garb & twin daggers; fastest walker in the fortress."),
        HEAVY_MELEE("Heavy Melee", new Color(130, 145, 165), new Color(85, 98, 115), "Steel plate & heavy heater shield; built to hold doorways."),
        SUPPORTER("Supporter", new Color(230, 175, 45), new Color(175, 125, 20), "Artisan apron, goggles & wrench; operates rooms and repairs machinery.");

        final String title;
        final Color mainColor;
        final Color shadeColor;
        final String description;

        BasicClass(String title, Color mainColor, Color shadeColor, String description) {
            this.title = title;
            this.mainColor = mainColor;
            this.shadeColor = shadeColor;
            this.description = description;
        }
    }

    // --- ROOM MODEL (With 4 Sub-Slots for Multiple Occupants) ---
    private static class RoomNode {
        final String id, name, stationLabel;
        final int gx, gy;
        final Color floorTint;
        final Rectangle bounds;
        final Point[] slotCenters = new Point[4];
        final CrewUnit[] slotOccupants = new CrewUnit[4];
        float consolePulse = 0f;

        RoomNode(String id, String name, String stationLabel, int gx, int gy, Color floorTint, int ox, int oy, int w, int h) {
            this.id = id;
            this.name = name;
            this.stationLabel = stationLabel;
            this.gx = gx;
            this.gy = gy;
            this.floorTint = floorTint;
            int rx = ox + gx * w;
            int ry = oy + gy * h;
            this.bounds = new Rectangle(rx, ry, w, h);

            // 4 Non-Overlapping Quadrant Sub-Slots inside the room
            int padX = 52, padY = 54;
            slotCenters[0] = new Point(rx + padX, ry + padY);             // Slot 0: Top-Left (Main Console)
            slotCenters[1] = new Point(rx + w - padX, ry + padY);         // Slot 1: Top-Right
            slotCenters[2] = new Point(rx + padX, ry + h - padY + 8);     // Slot 2: Bottom-Left
            slotCenters[3] = new Point(rx + w - padX, ry + h - padY + 8); // Slot 3: Bottom-Right
        }

        int getFirstFreeSlot() {
            for (int i = 0; i < 4; i++) {
                if (slotOccupants[i] == null) return i;
            }
            return -1;
        }
    }

    // --- ANIMATED DOOR MODEL ---
    public enum DoorMode { AUTO, HELD_OPEN, LOCKED }
    private static class Doorway {
        final RoomNode roomA, roomB;
        final boolean verticalWall; // true = connects left/right rooms; false = connects top/bottom rooms
        final Point center;
        final Rectangle hitbox;
        DoorMode mode = DoorMode.AUTO;
        float openAmount = 0f; // 0.0f = closed, 1.0f = wide open

        Doorway(RoomNode a, RoomNode b) {
            this.roomA = a;
            this.roomB = b;
            this.verticalWall = (a.gy == b.gy);
            int cx = (a.bounds.x + a.bounds.width / 2 + b.bounds.x + b.bounds.width / 2) / 2;
            int cy = (a.bounds.y + a.bounds.height / 2 + b.bounds.y + b.bounds.height / 2) / 2;
            this.center = new Point(cx, cy);
            this.hitbox = verticalWall
                ? new Rectangle(cx - 12, cy - 28, 24, 56)
                : new Rectangle(cx - 28, cy - 12, 56, 24);
        }

        RoomNode getNeighbor(RoomNode r) {
            if (r == roomA) return roomB;
            if (r == roomB) return roomA;
            return null;
        }
    }

    // --- CREW CHARACTER MODEL (With Smooth Pixel-Art Rig & Waypoint Queue) ---
    private static class CrewUnit {
        final String id;
        String name;
        BasicClass basicClass;
        RoomNode currentRoom;
        int assignedSlotIndex;
        float x, y;
        boolean facingRight = true;
        boolean moving = false;
        float walkCycle = 0f;
        float idleBreath = 0f;
        float squashStretch = 1.0f;
        float dustTimer = 0f;
        final Deque<Point> pixelWaypoints = new ArrayDeque<>();
        final Deque<RoomNode> roomQueue = new ArrayDeque<>();
        RoomNode destinationRoom;
        int destinationSlot;

        CrewUnit(String id, String name, BasicClass cls, RoomNode startRoom, int slotIdx) {
            this.id = id;
            this.name = name;
            this.basicClass = cls;
            this.currentRoom = startRoom;
            this.assignedSlotIndex = slotIdx;
            this.destinationRoom = startRoom;
            this.destinationSlot = slotIdx;
            startRoom.slotOccupants[slotIdx] = this;
            Point pt = startRoom.slotCenters[slotIdx];
            this.x = pt.x;
            this.y = pt.y;
            this.idleBreath = (float) (Math.random() * Math.PI * 2);
        }

        Rectangle getSpriteHitbox() {
            return new Rectangle((int) x - 20, (int) y - 42, 40, 56);
        }
    }

    // --- VISUAL JUICE EFFECTS (Footstep Dust, Click Ripples, Floating Popups) ---
    private static class DustPuff {
        float x, y, vx, vy, radius, alpha = 1.0f;
        Color color;
        DustPuff(float x, float y, float vx, float vy, float radius, Color color) {
            this.x = x; this.y = y; this.vx = vx; this.vy = vy; this.radius = radius; this.color = color;
        }
    }

    private static class ClickRipple {
        float x, y, radius = 4f, maxRadius = 36f, alpha = 1.0f;
        Color color;
        ClickRipple(float x, float y, Color color) { this.x = x; this.y = y; this.color = color; }
    }

    private static class FloatingText {
        String text;
        float x, y, alpha = 1.0f;
        Color color;
        FloatingText(String text, float x, float y, Color color) {
            this.text = text; this.x = x; this.y = y; this.color = color;
        }
    }

    // --- SANDBOX STATE ---
    private final Map<String, RoomNode> rooms = new LinkedHashMap<>();
    private final List<Doorway> doorways = new ArrayList<>();
    private final List<CrewUnit> crewList = new ArrayList<>();
    private final List<DustPuff> particles = new ArrayList<>();
    private final List<ClickRipple> ripples = new ArrayList<>();
    private final List<FloatingText> floatingTexts = new ArrayList<>();
    private final Map<BasicClass, Rectangle> classButtons = new EnumMap<>(BasicClass.class);

    private CrewUnit selectedCrew = null;
    private CrewUnit hoveredCrew = null;
    private RoomNode selectedRoom = null;
    private RoomNode hoveredRoom = null;
    private Doorway hoveredDoor = null;
    private int hoveredSlotIndex = -1;
    private String statusBanner = "Left-Click a Person to select them | Right-Click any Room Pad to walk there | Left-Click a Door to cycle it";

    public Fateweavers() {
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setBackground(BG_DARK);
        setFocusable(true);

        buildFortressHouse();
        spawnStartingCrew();
        setupMouseAndKeyControls();

        new javax.swing.Timer(16, this).start(); // 60 FPS loop
    }

    // =========================================================================
    // 1. INITIALIZE HOUSE LAYOUT & STARTING CREW
    // =========================================================================
    private void buildFortressHouse() {
        int ox = 140, oy = 110, roomW = 260, roomH = 195;

        // Top Row
        addRoom("MAGE_SPIRE", "Mage Spire", "Arcane Ward Station", 1, 0, new Color(46, 44, 64), ox, oy, roomW, roomH);
        addRoom("BARRACKS", "Barracks", "Weapon Rack & Drill", 2, 0, new Color(56, 46, 44), ox, oy, roomW, roomH);

        // Middle Row (Main Corridor Spine)
        addRoom("GATEHOUSE", "Gatehouse", "Bastion Entryway", 0, 1, new Color(52, 52, 56), ox, oy, roomW, roomH);
        addRoom("LOOM_HALL", "Fate Loom Hall", "Central Loom Core", 1, 1, new Color(44, 56, 62), ox, oy, roomW, roomH);
        addRoom("CHRYSALIS", "Chrysalis Ward", "Class Crucible & Med", 2, 1, new Color(46, 60, 52), ox, oy, roomW, roomH);
        addRoom("WORKSHOP", "Artificer Study", "Tinker Workbench", 3, 1, new Color(62, 52, 42), ox, oy, roomW, roomH);

        // Bottom Row
        addRoom("GRANARY", "Granary Hearth", "Provisions & Mess", 1, 2, new Color(58, 54, 44), ox, oy, roomW, roomH);
        addRoom("ALCHEMIST", "Alchemist Lab", "Brewing Stills", 2, 2, new Color(48, 58, 58), ox, oy, roomW, roomH);

        // Connect adjacent rooms with animated doorways
        connectRooms("GATEHOUSE", "LOOM_HALL");
        connectRooms("LOOM_HALL", "CHRYSALIS");
        connectRooms("CHRYSALIS", "WORKSHOP");
        connectRooms("MAGE_SPIRE", "LOOM_HALL");
        connectRooms("BARRACKS", "CHRYSALIS");
        connectRooms("MAGE_SPIRE", "BARRACKS");
        connectRooms("LOOM_HALL", "GRANARY");
        connectRooms("CHRYSALIS", "ALCHEMIST");
        connectRooms("GRANARY", "ALCHEMIST");
    }

    private void addRoom(String id, String name, String station, int gx, int gy, Color tint, int ox, int oy, int w, int h) {
        rooms.put(id, new RoomNode(id, name, station, gx, gy, tint, ox, oy, w, h));
    }

    private void connectRooms(String idA, String idB) {
        doorways.add(new Doorway(rooms.get(idA), rooms.get(idB)));
    }

    private void spawnStartingCrew() {
        // Spawn 4 characters (including 2 in the Fate Loom Hall so you can immediately test clicking separate people in one room)
        RoomNode loom = rooms.get("LOOM_HALL");
        RoomNode chrysalis = rooms.get("CHRYSALIS");
        RoomNode gate = rooms.get("GATEHOUSE");

        crewList.add(new CrewUnit("C1", "Aldric", BasicClass.UNCLASSED, loom, 0));
        crewList.add(new CrewUnit("C2", "Brenna", BasicClass.MAGIC, loom, 1));
        crewList.add(new CrewUnit("C3", "Cedric", BasicClass.HEAVY_MELEE, gate, 0));
        crewList.add(new CrewUnit("C4", "Daria", BasicClass.SUPPORTER, chrysalis, 0));

        selectedCrew = crewList.get(0);
        selectedRoom = loom;
    }

    // =========================================================================
    // 2. PATHFINDING & EXACT DOORWAY WAYPOINT GENERATION
    // =========================================================================
    private List<RoomNode> findRoomPath(RoomNode start, RoomNode goal) {
        if (start == goal) return List.of(start);
        Queue<RoomNode> queue = new ArrayDeque<>();
        Map<RoomNode, RoomNode> parentMap = new HashMap<>();
        Set<RoomNode> visited = new HashSet<>();

        queue.add(start);
        visited.add(start);

        while (!queue.isEmpty()) {
            RoomNode curr = queue.poll();
            if (curr == goal) {
                LinkedList<RoomNode> path = new LinkedList<>();
                for (RoomNode at = goal; at != null; at = parentMap.get(at)) {
                    path.addFirst(at);
                }
                return path;
            }
            for (Doorway d : doorways) {
                if (d.mode == DoorMode.LOCKED) continue; // Cannot path through locked doors
                RoomNode nb = d.getNeighbor(curr);
                if (nb != null && visited.add(nb)) {
                    parentMap.put(nb, curr);
                    queue.add(nb);
                }
            }
        }
        return Collections.emptyList();
    }

    private void orderCrewMove(CrewUnit unit, RoomNode targetRoom, int preferredSlot) {
        int slot = preferredSlot;
        if (slot < 0 || (targetRoom.slotOccupants[slot] != null && targetRoom.slotOccupants[slot] != unit)) {
            slot = targetRoom.getFirstFreeSlot();
        }
        if (slot < 0) {
            floatingTexts.add(new FloatingText("Room Full (4/4)!", targetRoom.bounds.x + 80, targetRoom.bounds.y + 40, new Color(255, 120, 90)));
            return;
        }

        List<RoomNode> roomPath = findRoomPath(unit.currentRoom, targetRoom);
        if (roomPath.isEmpty()) {
            floatingTexts.add(new FloatingText("Path Blocked by Locked Door!", unit.x, unit.y - 45, new Color(255, 110, 90)));
            return;
        }

        // Release old slot reservation and reserve new slot immediately
        unit.destinationRoom.slotOccupants[unit.destinationSlot] = null;
        targetRoom.slotOccupants[slot] = unit;
        unit.destinationRoom = targetRoom;
        unit.destinationSlot = slot;

        unit.pixelWaypoints.clear();
        unit.roomQueue.clear();

        // Build smooth pixel waypoints through every doorway center along the route
        for (int i = 0; i < roomPath.size() - 1; i++) {
            RoomNode rA = roomPath.get(i);
            RoomNode rB = roomPath.get(i + 1);
            Doorway door = findDoorBetween(rA, rB);
            if (door != null) {
                if (door.verticalWall) {
                    int dir = (rB.gx > rA.gx) ? 1 : -1;
                    unit.pixelWaypoints.add(new Point(door.center.x - dir * 24, door.center.y + 6));
                    unit.pixelWaypoints.add(new Point(door.center.x + dir * 24, door.center.y + 6));
                } else {
                    int dir = (rB.gy > rA.gy) ? 1 : -1;
                    unit.pixelWaypoints.add(new Point(door.center.x, door.center.y - dir * 24));
                    unit.pixelWaypoints.add(new Point(door.center.x, door.center.y + dir * 24));
                }
                unit.roomQueue.add(rB);
            }
        }

        // Final waypoint: exact sub-slot pad inside the destination room
        Point finalPt = targetRoom.slotCenters[slot];
        unit.pixelWaypoints.add(new Point(finalPt.x, finalPt.y));
        unit.squashStretch = 1.22f; // Little jump-start squash!
        ripples.add(new ClickRipple(finalPt.x, finalPt.y, CYAN_SELECT));
        statusBanner = unit.name + " (" + unit.basicClass.title + ") walking to " + targetRoom.name + " [Pad #" + (slot + 1) + "]";
    }
    private Doorway findDoorBetween(RoomNode a, RoomNode b) {
        for (Doorway d : doorways) {
            if ((d.roomA == a && d.roomB == b) || (d.roomA == b && d.roomB == a)) return d;
        }
        return null;
    }

    // =========================================================================
    // 3. REAL-TIME ANIMATION LOOP (60 FPS)
    // =========================================================================
    @Override
    public void actionPerformed(ActionEvent e) {
        float dt = 0.016f;

        // 1. Update Room Console Glow
        for (RoomNode r : rooms.values()) {
            if (r.slotOccupants[0] != null && !r.slotOccupants[0].moving && r.slotOccupants[0].currentRoom == r) {
                r.consolePulse += dt * 4.5f;
            }
        }

        // 2. Update Doorway Proximity Sensors & Sliding Animation
        for (Doorway d : doorways) {
            boolean someoneNear = false;
            if (d.mode == DoorMode.HELD_OPEN) {
                someoneNear = true;
            } else if (d.mode == DoorMode.AUTO) {
                for (CrewUnit u : crewList) {
                    if (Point2D.distance(u.x, u.y, d.center.x, d.center.y) < 54) {
                        someoneNear = true;
                        break;
                    }
                }
            }
            float targetOpen = someoneNear ? 1.0f : 0.0f;
            d.openAmount += (targetOpen - d.openAmount) * Math.min(1f, dt * 10f);
        }

        // 3. Update Crew Walking, Door Waiting, and Footstep Dust
        for (CrewUnit u : crewList) {
            u.idleBreath += dt * 3.2f;
            u.squashStretch += (1.0f - u.squashStretch) * Math.min(1f, dt * 9f);

            if (!u.pixelWaypoints.isEmpty()) {
                Point target = u.pixelWaypoints.peekFirst();

                // If approaching a closed door, wait briefly while it slides open
                Doorway blockingDoor = getDoorNearPoint(target);
                if (blockingDoor != null && blockingDoor.openAmount < 0.55f && Point2D.distance(u.x, u.y, blockingDoor.center.x, blockingDoor.center.y) < 40) {
                    u.moving = false;
                    continue;
                }

                u.moving = true;
                float dx = target.x - u.x;
                float dy = target.y - u.y;
                float dist = (float) Math.hypot(dx, dy);
                if (Math.abs(dx) > 1f) u.facingRight = (dx > 0);

                float speed = (u.basicClass == BasicClass.LIGHT_MELEE ? 195f : 145f);
                float step = speed * dt;

                u.walkCycle += dt * (u.basicClass == BasicClass.LIGHT_MELEE ? 16f : 12f);
                u.dustTimer += dt;
                if (u.dustTimer >= 0.14f) {
                    u.dustTimer = 0f;
                    particles.add(new DustPuff(u.x + (u.facingRight ? -6 : 6), u.y + 10,
                    (float) (Math.random() - 0.5) * 14f, -8f, 7f, new Color(195, 185, 170)));
                }

                if (dist <= step) {
                    u.x = target.x;
                    u.y = target.y;
                    u.pixelWaypoints.pollFirst();

                    // Update current room reference when stepping through a doorway
                    for (RoomNode r : rooms.values()) {
                        if (r.bounds.contains(u.x, u.y)) {
                            u.currentRoom = r;
                            break;
                        }
                    }

                    if (u.pixelWaypoints.isEmpty()) {
                        u.moving = false;
                        u.assignedSlotIndex = u.destinationSlot;
                        u.squashStretch = 0.84f; // Landing squash!
                    }
                } else {
                    u.x += (dx / dist) * step;
                    u.y += (dy / dist) * step;
                }
            } else {
                u.moving = false;
            }
        }

        // 4. Update Particles, Ripples & Floating Text
        particles.removeIf(p -> {
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.radius += dt * 12f;
            p.alpha -= dt * 2.2f;
            return p.alpha <= 0f;
        });

        ripples.removeIf(rp -> {
            rp.radius += dt * 65f;
            rp.alpha -= dt * 2.0f;
            return rp.alpha <= 0f;
        });

        floatingTexts.removeIf(ft -> {
            ft.y -= dt * 28f;
            ft.alpha -= dt * 0.85f;
            return ft.alpha <= 0f;
        });

        repaint();
    }

    private Doorway getDoorNearPoint(Point pt) {
        for (Doorway d : doorways) {
            if (Point2D.distance(pt.x, pt.y, d.center.x, d.center.y) < 32) return d;
        }
        return null;
    }

    // =========================================================================
    // 4. INPUT HANDLING (Independent Person vs. Door vs. Room Click Priority)
    // =========================================================================
    private void setupMouseAndKeyControls() {
        MouseAdapter mouseHandler = new MouseAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                Point pt = e.getPoint();
                hoveredCrew = null;
                hoveredDoor = null;
                hoveredRoom = null;
                hoveredSlotIndex = -1;

                // 1. Check Person Hover First (Top Priority)
                for (int i = crewList.size() - 1; i >= 0; i--) {
                    CrewUnit u = crewList.get(i);
                    if (u.getSpriteHitbox().contains(pt)) {
                        hoveredCrew = u;
                        break;
                    }
                }

                // 2. Check Door Hover
                if (hoveredCrew == null) {
                    for (Doorway d : doorways) {
                        if (d.hitbox.contains(pt)) {
                            hoveredDoor = d;
                            break;
                        }
                    }
                }

                // 3. Check Room & Sub-Slot Pad Hover
                for (RoomNode r : rooms.values()) {
                    if (r.bounds.contains(pt)) {
                        hoveredRoom = r;
                        for (int s = 0; s < 4; s++) {
                            if (Point2D.distance(pt.x, pt.y, r.slotCenters[s].x, r.slotCenters[s].y) <= 26) {
                                hoveredSlotIndex = s;
                                break;
                            }
                        }
                        break;
                    }
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {
                Point pt = e.getPoint();

                // RIGHT-CLICK: Move Selected Crew to Clicked Room / Specific Sub-Slot Pad
                if (SwingUtilities.isRightMouseButton(e)) {
                    if (selectedCrew != null) {
                        for (RoomNode r : rooms.values()) {
                            if (r.bounds.contains(pt)) {
                                int chosenSlot = -1;
                                for (int s = 0; s < 4; s++) {
                                    if (Point2D.distance(pt.x, pt.y, r.slotCenters[s].x, r.slotCenters[s].y) <= 32) {
                                        chosenSlot = s;
                                        break;
                                    }
                                }
                                orderCrewMove(selectedCrew, r, chosenSlot);
                                return;
                            }
                        }
                    }
                    return;
                }

                // LEFT-CLICK PRIORITY 1: Bottom HUD Class Outfitter Buttons
                if (selectedCrew != null) {
                    for (Map.Entry<BasicClass, Rectangle> entry : classButtons.entrySet()) {
                        if (entry.getValue().contains(pt)) {
                            selectedCrew.basicClass = entry.getKey();
                            selectedCrew.squashStretch = 1.3f;
                            for (int i = 0; i < 8; i++) {
                                double ang = i * Math.PI / 4;
                                particles.add(new DustPuff(selectedCrew.x, selectedCrew.y - 14,
                                (float) Math.cos(ang) * 40f, (float) Math.sin(ang) * 40f, 8f, entry.getKey().mainColor));
                            }
                            floatingTexts.add(new FloatingText("Class -> " + entry.getKey().title + "!",
                            selectedCrew.x - 45, selectedCrew.y - 50, entry.getKey().mainColor));
                            statusBanner = selectedCrew.name + " equipped as [" + entry.getKey().title + "]!";
                            return;
                        }
                    }
                }

                // LEFT-CLICK PRIORITY 2: Click a Specific Person (Even with multiple people in the same room!)
                for (int i = crewList.size() - 1; i >= 0; i--) {
                    CrewUnit u = crewList.get(i);
                    if (u.getSpriteHitbox().contains(pt)) {
                        selectedCrew = u;
                        selectedRoom = u.currentRoom;
                        u.squashStretch = 1.2f;
                        ripples.add(new ClickRipple(u.x, u.y + 8, CYAN_SELECT));
                        statusBanner = "Selected Person: " + u.name + " (" + u.basicClass.title + ") in " + u.currentRoom.name;
                        return;
                    }
                }

                // LEFT-CLICK PRIORITY 3: Click a Doorway to Cycle (AUTO -> HELD OPEN -> LOCKED)
                for (Doorway d : doorways) {
                    if (d.hitbox.contains(pt)) {
                        d.mode = switch (d.mode) {
                            case AUTO -> DoorMode.HELD_OPEN;
                            case HELD_OPEN -> DoorMode.LOCKED;
                            case LOCKED -> DoorMode.AUTO;
                        };
                        Color c = d.mode == DoorMode.LOCKED ? Color.RED : (d.mode == DoorMode.HELD_OPEN ? Color.GREEN : GOLD_ACCENT);
                        floatingTexts.add(new FloatingText("Door: " + d.mode.name(), d.center.x - 32, d.center.y - 18, c));
                        statusBanner = "Doorway between " + d.roomA.name + " and " + d.roomB.name + " set to " + d.mode.name();
                        return;
                    }
                }

                // LEFT-CLICK PRIORITY 4: Click the Room Itself
                for (RoomNode r : rooms.values()) {
                    if (r.bounds.contains(pt)) {
                        selectedRoom = r;
                        ripples.add(new ClickRipple(pt.x, pt.y, GOLD_ACCENT));
                        long count = crewList.stream().filter(u -> u.currentRoom == r).count();
                        statusBanner = "Selected Room: [" + r.name + "] — Station: " + r.stationLabel + " | Occupants: " + count + "/4";
                        return;
                    }
                }
            }
        };

        addMouseListener(mouseHandler);
        addMouseMotionListener(mouseHandler);

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_1 -> selectCrew(0);
                    case KeyEvent.VK_2 -> selectCrew(1);
                    case KeyEvent.VK_3 -> selectCrew(2);
                    case KeyEvent.VK_4 -> selectCrew(3);
                }
            }
        });
    }

    private void selectCrew(int idx) {
        if (idx >= 0 && idx < crewList.size()) {
            selectedCrew = crewList.get(idx);
            selectedRoom = selectedCrew.currentRoom;
            selectedCrew.squashStretch = 1.2f;
        }
    }

    // =========================================================================
    // 5. RENDERING ENGINE (Rooms, Animated Doors, Custom Pixel-Outlined Sprites)
    // =========================================================================
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        drawHeaderBar(g2);
        drawFortressRooms(g2);
        drawAnimatedDoors(g2);
        drawPathPreviewAndRipples(g2);
        drawDustParticles(g2);
        drawCrewSpritesSortedByY(g2);
        drawFloatingTexts(g2);
        drawBottomInspectorAndClassBar(g2);
    }

    private void drawHeaderBar(Graphics2D g2) {
        g2.setColor(new Color(32, 29, 36));
        g2.fillRect(0, 0, WIDTH, 64);
        g2.setColor(new Color(90, 82, 74));
        g2.drawLine(0, 64, WIDTH, 64);

        g2.setFont(new Font("Monospaced", Font.BOLD, 17));
        g2.setColor(GOLD_ACCENT);
        g2.drawString("FATEWEAVERS — MODULE 1: LIVING FORTRESS & CHARACTER SANDBOX", 24, 28);

        g2.setFont(new Font("Monospaced", Font.PLAIN, 13));
        g2.setColor(new Color(210, 205, 195));
        g2.drawString(statusBanner, 24, 50);
    }
    private void drawFortressRooms(Graphics2D g2) {
        for (RoomNode r : rooms.values()) {
            Rectangle b = r.bounds;
            boolean isSel = (r == selectedRoom);
            boolean isHov = (r == hoveredRoom && hoveredCrew == null && hoveredDoor == null);

            // Room Floor Tile Grid
            g2.setColor(r.floorTint);
            g2.fillRect(b.x, b.y, b.width, b.height);

            // Subtle interior stone floor tiles
            g2.setColor(new Color(255, 255, 255, 12));
            for (int x = b.x + 32; x < b.x + b.width; x += 32) g2.drawLine(x, b.y, x, b.y + b.height);
            for (int y = b.y + 32; y < b.y + b.height; y += 32) g2.drawLine(b.x, y, b.x + b.width, y);

            // Room Selection / Hover Highlight
            if (isSel) {
                g2.setColor(new Color(240, 195, 75, 35));
                g2.fillRect(b.x + 6, b.y + 6, b.width - 12, b.height - 12);
            } else if (isHov) {
                g2.setColor(new Color(255, 255, 255, 18));
                g2.fillRect(b.x + 6, b.y + 6, b.width - 12, b.height - 12);
            }

            // Draw the 4 Quadrant Sub-Slot Pads
            for (int s = 0; s < 4; s++) {
                Point pad = r.slotCenters[s];
                boolean padHov = (r == hoveredRoom && hoveredSlotIndex == s && hoveredCrew == null);
                g2.setColor(padHov ? new Color(85, 215, 255, 90) : new Color(0, 0, 0, 55));
                g2.fillOval(pad.x - 22, pad.y - 9, 44, 22);
                g2.setColor(padHov ? CYAN_SELECT : new Color(150, 145, 135, 90));
                g2.drawOval(pad.x - 22, pad.y - 9, 44, 22);

                // Slot 0 features an interactive station console right above the pad
                if (s == 0) {
                    int cx = pad.x - 18, cy = pad.y - 38;
                    g2.setColor(new Color(35, 32, 38));
                    g2.fillRoundRect(cx, cy, 36, 18, 6, 6);
                    boolean manned = (r.slotOccupants[0] != null && !r.slotOccupants[0].moving && r.slotOccupants[0].currentRoom == r);
                    int glow = manned ? (int) (180 + 70 * Math.sin(r.consolePulse)) : 70;
                    g2.setColor(manned ? new Color(70, glow, 220) : new Color(90, 85, 80));
                    g2.fillRect(cx + 5, cy + 4, 26, 8);
                    g2.setColor(OUTLINE_BLACK);
                    g2.drawRoundRect(cx, cy, 36, 18, 6, 6);
                }
            }

            // Thick Cutaway Fortress Stone Walls
            g2.setStroke(new BasicStroke(6f));
            g2.setColor(isSel ? GOLD_ACCENT : new Color(115, 108, 100));
            g2.drawRect(b.x, b.y, b.width, b.height);
            g2.setStroke(new BasicStroke(2f));
            g2.setColor(OUTLINE_BLACK);
            g2.drawRect(b.x + 3, b.y + 3, b.width - 6, b.height - 6);
            g2.setStroke(new BasicStroke(1f));

            // Room Header Banner
            g2.setColor(new Color(24, 22, 26, 200));
            g2.fillRoundRect(b.x + 70, b.y + 8, b.width - 140, 22, 8, 8);
            g2.setFont(new Font("Monospaced", Font.BOLD, 12));
            g2.setColor(isSel ? GOLD_ACCENT : new Color(225, 218, 205));
            FontMetrics fm = g2.getFontMetrics();
            int tx = b.x + (b.width - fm.stringWidth(r.name)) / 2;
            g2.drawString(r.name, tx, b.y + 23);
        }
    }

    private void drawAnimatedDoors(Graphics2D g2) {
        for (Doorway d : doorways) {
            // Clear wall gap for doorway
            g2.setColor( new Color(38, 36, 40));
            if (d.verticalWall) {
                g2.fillRect(d.center.x - 8, d.center.y - 26, 16, 52);
            } else {
                g2.fillRect(d.center.x - 26, d.center.y - 8, 52, 16);
            }

            // Sliding Double-Door Panels (parting outward as d.openAmount approaches 1.0f)
            Color panelColor = switch (d.mode) {
                case LOCKED -> new Color(175, 55, 55);
                case HELD_OPEN -> new Color(75, 165, 105);
                case AUTO -> new Color(165, 130, 85);
            };

            int slideOffset = (int) (d.openAmount * 19);
            if (d.verticalWall) {
                // Top panel slides up, bottom panel slides down
                int panelLen = 24 - slideOffset;
                if (panelLen > 2) {
                    g2.setColor(panelColor);
                    g2.fillRect(d.center.x - 5, d.center.y - 24, 10, panelLen);
                    g2.fillRect(d.center.x - 5, d.center.y + 24 - panelLen, 10, panelLen);
                    g2.setColor(OUTLINE_BLACK);
                    g2.drawRect(d.center.x - 5, d.center.y - 24, 10, panelLen);
                    g2.drawRect(d.center.x - 5, d.center.y + 24 - panelLen, 10, panelLen);
                }
            } else {
                // Left panel slides left, right panel slides right
                int panelLen = 24 - slideOffset;
                if (panelLen > 2) {
                    g2.setColor(panelColor);
                    g2.fillRect(d.center.x - 24, d.center.y - 5, panelLen, 10);
                    g2.fillRect(d.center.x + 24 - panelLen, d.center.y - 5, panelLen, 10);
                    g2.setColor(OUTLINE_BLACK);
                    g2.drawRect(d.center.x - 24, d.center.y - 5, panelLen, 10);
                    g2.drawRect(d.center.x + 24 - panelLen, d.center.y - 5, panelLen, 10);
                }
            }

            // Door Frame & Status Light Pip
            if (d == hoveredDoor) {
                g2.setColor(CYAN_SELECT);
                g2.drawRect(d.hitbox.x, d.hitbox.y, d.hitbox.width, d.hitbox.height);
            }
            Color light = d.mode == DoorMode.LOCKED ? Color.RED : (d.openAmount > 0.5f ? Color.GREEN : GOLD_ACCENT);
            g2.setColor(light);
            g2.fillOval(d.center.x - 3, d.center.y - 3, 6, 6);
        }
    }

    private void drawPathPreviewAndRipples(Graphics2D g2) {
        if (selectedCrew != null && !selectedCrew.pixelWaypoints.isEmpty()) {
            Stroke old = g2.getStroke();
            g2.setStroke(new BasicStroke(2.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 0, new float[]{6f, 6f}, 0));
            g2.setColor(CYAN_SELECT);
            int px = (int) selectedCrew.x;
            int py = (int) selectedCrew.y;
            for (Point wp : selectedCrew.pixelWaypoints) {
                g2.drawLine(px, py, wp.x, wp.y);
                px = wp.x;
                py = wp.y;
            }
            g2.setStroke(old);
        }

        for (ClickRipple rp : ripples) {
            g2.setColor(new Color(rp.color.getRed(), rp.color.getGreen(), rp.color.getBlue(), (int) (Math.max(0, rp.alpha) * 255)));
            int r = (int) rp.radius;
            g2.drawOval((int) rp.x - r, (int) rp.y - r / 2, r * 2, r);
        }
    }

    private void drawDustParticles(Graphics2D g2) {
        for (DustPuff p : particles) {
            g2.setColor(new Color(p.color.getRed(), p.color.getGreen(), p.color.getBlue(), (int) (Math.max(0, p.alpha) * 160)));
            int r = (int) p.radius;
            g2.fillOval((int) p.x - r / 2, (int) p.y - r / 2, r, r);
        }
    }

    // =========================================================================
    // 6. PROCEDURAL PIXEL-OUTLINED CHARACTER SPRITE RENDERER (Matches Image)
    // =========================================================================
    private void drawCrewSpritesSortedByY(Graphics2D g2) {
        List<CrewUnit> sorted = new ArrayList<>(crewList);
        sorted.sort(Comparator.comparingDouble(u -> u.y));
        for (CrewUnit u : sorted) {
            drawSingleCharacterSprite(g2, u);
        }
    }

    private void drawSingleCharacterSprite(Graphics2D g2, CrewUnit u) {
        boolean isSel = (u == selectedCrew);
        boolean isHov = (u == hoveredCrew);

        // 1. Floor Shadow & Selection Halo
        if (isSel || isHov) {
            g2.setColor(isSel ? CYAN_SELECT : Color.WHITE);
            g2.setStroke(new BasicStroke(2.2f));
            g2.drawOval((int) u.x - 19, (int) u.y - 1, 38, 16);
            g2.setStroke(new BasicStroke(1f));
        }
        g2.setColor(new Color(0, 0, 0, 110));
        g2.fillOval((int) u.x - 14, (int) u.y + 1, 28, 12);

        // 2. Compute Walk Stride, Bobbing & Squash-Stretch Transform
        float legSwing = u.moving ? (float) Math.sin(u.walkCycle) * 5.5f : 0f;
        float armSwing = u.moving ? (float) -Math.sin(u.walkCycle) * 5.0f : (float) Math.sin(u.idleBreath * 2f) * 1.2f;
        float bodyBob = u.moving ? (float) Math.abs(Math.sin(u.walkCycle)) * -3.5f : (float) Math.sin(u.idleBreath) * 1.2f;

        AffineTransform oldTransform = g2.getTransform();
        g2.translate(u.x, u.y + bodyBob);
        float scaleX = (u.facingRight ? 1f : -1f) * (2.0f - u.squashStretch);
        float scaleY = u.squashStretch;
        g2.scale(scaleX, scaleY);

        Color suitMain = u.basicClass.mainColor;
        Color suitShade = u.basicClass.shadeColor;

        // 3. Back Arm (Behind Torso)
        drawOutlinedRoundedRect(g2, 6, (int) (-21 + armSwing * 0.6f), 7, 13, 4, suitShade, OUTLINE_BLACK);
        drawOutlinedRoundedRect(g2, 7, (int) (-11 + armSwing * 0.6f), 6, 5, 3, SKIN_SHADE, OUTLINE_BLACK);

        // 4. Left & Right Boots/Legs (Alternating Stride)
        int leftLegY = (int) (-9 + Math.max(0, legSwing));
        int rightLegY = (int) (-9 + Math.max(0, -legSwing));
        drawOutlinedRoundedRect(g2, -9, leftLegY, 8, 11, 4, suitShade, OUTLINE_BLACK);
        drawOutlinedRoundedRect(g2, -10, leftLegY + 7, 9, 5, 3, suitMain.darker(), OUTLINE_BLACK);

        drawOutlinedRoundedRect(g2, 1, rightLegY, 8, 11, 4, suitMain, OUTLINE_BLACK);
        drawOutlinedRoundedRect(g2, 1, rightLegY + 7, 9, 5, 3, suitShade, OUTLINE_BLACK);

        // 5. Torso / Jumpsuit Tunic (With Left-Side Shading & Center Seam like Reference Sprite)
        drawOutlinedRoundedRect(g2, -10, -24, 20, 17, 6, suitMain, OUTLINE_BLACK);
        g2.setColor(suitShade);
        g2.fillRoundRect(-8, -22, 6, 13, 4, 4); // Two-tone left shading
        g2.setColor( suitShade.darker());
        g2.drawLine(1, -22, 1, -8); // Center tunic seam

        // 6. Front Arm & Hand
        drawOutlinedRoundedRect(g2, -14, (int) (-21 - armSwing), 8, 13, 4, suitMain, OUTLINE_BLACK);
        drawOutlinedRoundedRect(g2, -13, (int) (-11 - armSwing), 6, 6, 3, SKIN_LIGHT, OUTLINE_BLACK);

        // 7. Large Rounded Faceless Head (Two-Tone Shaded Peach Oval with Thick Pixel Outline)
        g2.setColor(OUTLINE_BLACK);
        g2.fillOval(-13, -44, 26, 25);
        g2.setColor(SKIN_LIGHT);
        g2.fillOval(-11, -42, 22, 21);
        g2.setColor(SKIN_SHADE);
        g2.fillArc(-11, -42, 22, 21, 115, 165); // Warm crescent shadow on left cheek/neck

        // 8. Class-Specific Visual Gear Overlay (For the 5 Basic Classes)
        drawClassGearOverlay(g2, u.basicClass, armSwing);

        g2.setTransform(oldTransform);

        // 9. Floating Nameplate & Class Badge When Hovered or Selected
        if (isSel || isHov) {
            g2.setFont(new Font("Monospaced", Font.BOLD, 11));
            String tag = u.name + " [" + u.basicClass.title + "]";
            int tw = g2.getFontMetrics().stringWidth(tag);
            int bx = (int) u.x - tw / 2 - 6;
            int by = (int) u.y - 62;
            g2.setColor(new Color(20, 18, 24, 220));
            g2.fillRoundRect(bx, by, tw + 12, 18, 6, 6);
            g2.setColor(isSel ? CYAN_SELECT : GOLD_ACCENT);
            g2.drawRoundRect(bx, by, tw + 12, 18, 6, 6);
            g2.drawString(tag, bx + 6, by + 13);
        }
    }

    private void drawClassGearOverlay(Graphics2D g2, BasicClass cls, float armSwing) {
        switch (cls) {
            case MAGIC -> {
                // Pointed Arcane Hat & Floating Cyan Mana Orb
                int[] hx = {-14, 0, 14};
                int[] hy = {-39, -54, -39};
                g2.setColor(cls.mainColor);
                g2.fillPolygon(hx, hy, 3);
                g2.setColor(OUTLINE_BLACK);
                g2.setStroke(new BasicStroke(2f));
                g2.drawPolygon(hx, hy, 3);
                g2.setColor(CYAN_SELECT);
                g2.fillOval(14, (int) (-28 + armSwing), 8, 8);
                g2.setColor(OUTLINE_BLACK);
                g2.drawOval(14, (int) (-28 + armSwing), 8, 8);
            }
            case RANGED -> {
                // Ranger Feather Cap & Curved Bow in hand
                drawOutlinedRoundedRect(g2, -12, -44, 24, 6, 3, cls.shadeColor, OUTLINE_BLACK);
                g2.setColor(new Color(160, 105, 55));
                g2.setStroke(new BasicStroke(2.2f));
                g2.drawArc(8, -26, 10, 20, -80, 160);
            }
            case LIGHT_MELEE -> {
                // Rogue Headband + Twin Steel Daggers
                g2.setColor(cls.mainColor);
                g2.fillRect(-11, -38, 22, 4);
                g2.setColor(new Color(220, 230, 240));
                g2.fillRect(-18, (int) (-9 - armSwing), 9, 3);
                g2.fillRect(11, (int) (-9 + armSwing), 9, 3);
            }
            case HEAVY_MELEE -> {
                // Steel Shoulder Pauldrons & Heater Shield
                drawOutlinedRoundedRect(g2, -15, -24, 8, 7, 3, new Color(190, 205, 220), OUTLINE_BLACK);
                drawOutlinedRoundedRect(g2, 8, -19, 9, 14, 4, new Color(180, 195, 215), OUTLINE_BLACK);
                g2.setColor(GOLD_ACCENT);
                g2.drawRect(11, -16, 3, 8);
            }
            case SUPPORTER -> {
                // Tinker Brass Goggles on Forehead & Iron Wrench
                drawOutlinedRoundedRect(g2, -9, -38, 8, 6, 2, GOLD_ACCENT, OUTLINE_BLACK);
                drawOutlinedRoundedRect(g2, 1, -38, 8, 6, 2, GOLD_ACCENT, OUTLINE_BLACK);
                g2.setColor(new Color(180, 190, 200));
                g2.fillRect(-16, (int) (-16 - armSwing), 4, 10);
            }
            case UNCLASSED -> {
                // Pure unadorned jumpsuit matching the uploaded base sprite
            }
        }
        g2.setStroke(new BasicStroke(1f));
    }

    private void drawOutlinedRoundedRect(Graphics2D g2, int x, int y, int w, int h, int arc, Color fill, Color outline) {
        g2.setColor(outline);
        g2.fillRoundRect(x - 2, y - 2, w + 4, h + 4, arc + 2, arc + 2);
        g2.setColor(fill);
        g2.fillRoundRect(x, y, w, h, arc, arc);
    }

    private void drawFloatingTexts(Graphics2D g2) {
        g2.setFont(new Font("Monospaced", Font.BOLD, 13));
        for (FloatingText ft : floatingTexts) {
            int a = (int) (Math.max(0f, Math.min(1f, ft.alpha)) * 255);
            g2.setColor(new Color(0, 0, 0, a));
            g2.drawString(ft.text, (int) ft.x + 1, (int) ft.y + 1);
            g2.setColor(new Color(ft.color.getRed(), ft.color.getGreen(), ft.color.getBlue(), a));
            g2.drawString(ft.text, (int) ft.x, (int) ft.y);
        }
    }

    private void drawBottomInspectorAndClassBar(Graphics2D g2) {
        int barY = HEIGHT - 122;
        g2.setColor(new Color(30, 27, 34));
        g2.fillRect(0, barY, WIDTH, 122);
        g2.setColor(new Color(95, 88, 78));
        g2.drawLine(0, barY, WIDTH, barY);

        // Left Panel: Selected Crew & Room Inspector
        g2.setFont(new Font("Monospaced", Font.BOLD, 14));
        if (selectedCrew != null) {
            g2.setColor(CYAN_SELECT);
            g2.drawString("SELECTED PERSON: " + selectedCrew.name + " [" + selectedCrew.basicClass.title + "] (Keys 1-4 to switch)", 24, barY + 26);
            g2.setFont(new Font("Monospaced", Font.PLAIN, 12));
            g2.setColor(new Color(210, 205, 195));
            g2.drawString(selectedCrew.basicClass.description, 24, barY + 46);
        }
        if (selectedRoom != null) {
            g2.setFont(new Font("Monospaced", Font.BOLD, 13));
            g2.setColor(GOLD_ACCENT);
            g2.drawString("SELECTED ROOM: " + selectedRoom.name + " (" + selectedRoom.stationLabel + ")", 24, barY + 74);
            g2.setFont(new Font("Monospaced", Font.PLAIN, 12));
            g2.setColor(new Color(185, 180, 170));
            g2.drawString("Tip: Click a person in a shared room to pick them; Right-Click a pad to walk.", 24, barY + 94);
        }

        // Right Panel: Instant 5 Basic Classes Outfitter Buttons
        classButtons.clear();
        BasicClass[] classes = BasicClass.values();
        int startX = 650;
        g2.setFont(new Font("Monospaced", Font.BOLD, 12));
        g2.setColor(GOLD_ACCENT);
        g2.drawString("CLICK TO EQUIP CLASS ON SELECTED PERSON (UNCLASSED + 5 BASIC ARCHETYPES):", startX, barY + 22);

        for (int i = 0; i < classes.length; i++) {
            BasicClass bc = classes[i];
            int bx = startX + (i % 3) * 230;
            int by = barY + 32 + (i / 3) * 40;
            Rectangle btn = new Rectangle(bx, by, 218, 34);
            classButtons.put(bc, btn);

            boolean active = (selectedCrew != null && selectedCrew.basicClass == bc);
            g2.setColor(active ? bc.mainColor : new Color(46, 43, 52));
            g2.fillRoundRect(btn.x, btn.y, btn.width, btn.height, 8, 8);
            g2.setColor(active ? Color.WHITE : bc.mainColor);
            g2.drawRoundRect(btn.x, btn.y, btn.width, btn.height, 8, 8);

            g2.setColor(Color.WHITE);
            g2.drawString(bc.title, btn.x + 14, btn.y + 22);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Fateweavers — Module 1: Fortress House & Character Sandbox");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setContentPane(new Fateweavers());
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}
